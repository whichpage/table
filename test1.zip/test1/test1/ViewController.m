//
//  ViewController.m
//  test1
//
//  Created by i on 2024/1/4.
//

#import "ViewController.h"
#import "ZhiKuTFMJContentCell.h"

#define textHeight @"textHeight"
#define labelHeight @"labelHeight"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) ZhiKuTFMJMenuListModel *model;
@property (nonatomic, strong) NSMutableArray *dataArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass(ZhiKuTFMJContentCell.class) bundle:nil] forCellReuseIdentifier:NSStringFromClass(ZhiKuTFMJContentCell.class)];
    [self loadData];
}

- (void)loadData{
    
    ZhiKuTFMJMenuListModel *model = [[ZhiKuTFMJMenuListModel alloc] init];
    _model = model;
    
    NSString *tableJson = @"[{\"table\":[[\"分类依据\",\"内容\"],[\"业务范围分类\",\"技术控制\"],[null,\"质量控制\"],[null,\"资金控制\"],[null,\"人力资源控制\"],[\"按时间分类\",\"日常控制\"],[null,\"定期控制\"],[\"按覆盖面分类\",\"专题控制\"],[null,\"专项控制\"],[null,\"全面控制\"],[\"按控制方式分类\",\"间接控制\"],[null,\"直接控制\"],[\"按作用环节分类\",\"①前馈控制：计划实施前采取预防措施防止问题的发生，而不是在实施中出现问题后的补救\"],[null,\"②同期控制：其纠正措施是在计划执行的过程中、对执行计划的各个环节质量进行控制\"],[null,\"③反馈控制：发生在行动之后、对出现的偏差进行纠正，防止偏差的继续发展或再度发生\"]],\"rowspans\":[{\"row\":1,\"col\":0,\"rowspan\":4},{\"row\":5,\"col\":0,\"rowspan\":2},{\"row\":7,\"col\":0,\"rowspan\":3},{\"row\":10,\"col\":0,\"rowspan\":2},{\"row\":12,\"col\":0,\"rowspan\":3}]},{\"table\":[[\"4个阶段\",\"8个步骤\",\"特点\"],[\"P：计划\",\"①分析现状，找出存在的质量问题；②分析产生问题的各种影响因素；③找出主要因素；④针对影响质量的主要因素，制订工作计划和活动措施。\",\"①是一个有机的整体\\n②大循环套小循环，互相衔接，互相促进\\n③阶梯式的运行，不断上升的循环\\n④处理阶段是PDCA循环的关键环节\"],[\"D：实施\",\"⑤按照制定的计划措施认真执行\",null],[\"C：检查\",\"⑥根据计划的要求，检查实际执行的效果，判断是否达到预期的结果。\",null],[\"A：处理\",\"⑦肯定成功的经验，形成标准、制度或规定，知道今后的工作；总结记录失败的教训，作为前车之鉴，防止以后再次发生类似事件。⑧提出这一循环中存在的问题，并转入下一循环去解决。\",null]],\"rowspans\":[{\"row\":1,\"col\":2,\"rowspan\":4}]},{\"table\":[[\"疾病判断公式\"],[\"#急性上呼吸道感染#=咽痛+咳嗽+发热\"],[\"#急性感染性喉炎#=犬吠样咳嗽+声嘶+吸气性喉鸣+三凹征\"],[\"#急性支气管炎#=干咳、痰少，啰音位置易变\"],[\"#哮喘性支气管炎#=喘，哮喘音，呼气性呼吸困难，湿疹或其他过敏史\"],[\"#毛细支气管炎#=喘，哮鸣音，呼气性呼吸困难，肺气肿或肺不张\"],[\"#肺炎链球菌肺炎#=病前上感或淋雨+咳铁锈色痰+稽留热\"],[\"#肺炎合并心力衰竭#=呼吸＞60次/分+心率＞180次/分+右心衰体征（心音低钝、奔马律、颈静脉怒张、肝大）\"],[\"#肺炎合并急性肺水肿#=咳粉红色泡沫痰+呼吸困难\"],[\"#肺炎链球菌肺炎#=病前上感或淋雨+咳铁锈色痰+稽留热\"],[\"#肺炎合并心力衰竭#=呼吸＞60次/分+心率＞180次/分+右心衰体征（心音低钝、奔马律、颈静脉怒张、肝大）\"],[\"#肺炎合并急性肺水肿#=咳粉红色泡沫痰+呼吸困难\"],[\"#肺炎合并中毒性肠麻痹#=肠鸣音消失+腹胀+呼吸困难加重\"],[\"#肺炎合并脑水肿、中毒性脑病#=嗜睡+惊厥+昏迷+呼吸不规则\"],[\"#肺炎合并脓胸#=呼吸困难突然加重+叩诊浊音\"],[\"#肺炎合并脓气胸#=呼吸困难突然加重+叩诊鼓音+叩诊浊音\"],[\"#克雷伯杆菌肺炎#=咳砖红色痰+X线空洞\"],[\"#支原体肺炎#=儿童+刺激性干咳+痰少+全身中毒症状轻+抗生素无效\"],[\"#腺病毒肺炎#=剧烈咳嗽+喘憋+呼吸困难\"],[\"#金黄色葡萄球菌肺炎#=高热+咳黄脓痰+并发脓胸+X线片状影\"],[\"#支气管扩张#=童年有麻疹百日咳或支气管肺炎迁延不愈病史+咳嗽+咳大量脓痰分三层+咯血+肺部局限性湿啰音\"],[\"#支气管哮喘#=接触变应原（粉尘、花朵、猫狗）+呼气性呼吸困难+哮鸣音\"],[\"慢性阻塞性肺疾病=老年人（吸烟史）+咳痰喘+桶状胸+FEV1/FVC＜70%\"],[\"#慢性肺源性心脏病#=慢阻肺病史+ 呼吸衰竭（呼吸困难、发绀）+右心衰竭（颈静脉怒张、肝大、肝颈静脉回流征阳性、下肢水肿）\"],[\"#Ⅰ型呼吸衰竭#=ARDS病史+呼吸困难+发绀+ PaO₂<60mmHg + PaCO₂正常或降低\"],[\"#Ⅱ型呼吸衰竭#=COPD病史+呼吸困难+发绀+ PaO₂<60mmHg + PaCO₂>50mmHg\"],[\"#张力性气胸#=胸部外伤史+皮下气肿\"],[\"#开放性气胸#=胸部外伤史+纵隔扑动+胸壁有开放性伤口+胸壁伤口处有声音\"],[\"#自发性气胸#=（COPD、肺结核、支气管哮喘）病史+突然胸痛+呼吸困难\"],[\"#血胸#=胸外伤史+气管偏移+叩诊浊音+呼吸音减弱\"],[\"#急性呼吸窘迫综合征#=严重低氧血症+急性进行性呼吸窘迫\"]],\"rowspans\":[]}]";
        
    NSMutableArray *result = [NSMutableArray array];
    NSMutableArray *height = [NSMutableArray array];
    
    NSData *jsonData = [tableJson dataUsingEncoding:NSUTF8StringEncoding];
    if (jsonData) {
        NSArray *tableJsonArr = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];
        for (NSDictionary *dic in tableJsonArr) {
            NSArray *arr1 = [dic objectForKey:@"table"];
            NSMutableArray *r1 = [NSMutableArray array];
            NSMutableArray *h1 = [NSMutableArray array];
            
            NSMutableArray *a0;
            NSMutableArray *a1;
            NSMutableArray *a2;
            for (NSArray *arr2 in arr1.reverseObjectEnumerator.allObjects) {// 合并时为 有值到nul 倒着遍历计算容易分组
                BOOL null = NO;
                for (NSString *str in arr2) {
                    if ([str isKindOfClass:[NSNull class]]) {
                        null = YES;
                        break;
                    }
                }
                for (int i = 0; i<arr2.count; i++) {
                    NSString *str = arr2[i];
                    NSInteger col = arr2.count >3 ?3 :arr2.count;
                    CGFloat maxW = ([UIScreen mainScreen].bounds.size.width - 12 *2 - 10 *col *2 - (col +1)) / col;
                    
                    id dat;
                    if (![str isKindOfClass:[NSNull class]]) {
                        str = [NSString stringWithFormat:@"%@",str];
                        NSMutableAttributedString *att = [self attributedTextFromString:str];
                        dat = [NSMutableDictionary dictionary];
                        [dat setValue:att forKey:@"att"];
                        
                        CGRect rect = [att boundingRectWithSize:CGSizeMake(maxW, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading context:nil];
                        CGFloat height = ceilf(rect.size.height ) + 21; //加上label上下间距 跟一条线的高度 作为一个整体计算
                        [dat setValue:@(height) forKey:textHeight];
                    }else{
                        dat = [NSNull null];
                    }
                    if (i == 0) {
                        if (!a0) {
                            a0 = [NSMutableArray array];
                        }
                        [a0 addObject:dat];
                    } else if (i == 1) {
                        if (!a1) {
                            a1 = [NSMutableArray array];
                        }
                        [a1 addObject:dat];
                    } else if (i == 2) {
                        if (!a2) {
                            a2 = [NSMutableArray array];
                        }
                        [a2 addObject:dat];
                    }
                    if (i == arr2.count - 1) {
                        if (!null) { //一组数据结束
                            NSMutableArray *r2 = [NSMutableArray array];
                            CGFloat maxH = 0;
                            
                            CGFloat f0 = 0;
                            CGFloat f1 = 0;
                            CGFloat f2 = 0;
                            NSMutableDictionary *dic0;
                            NSMutableDictionary *dic1;
                            NSMutableDictionary *dic2;
                            
                            BOOL v0 = NO;;
                            BOOL v1 = NO;;
                            BOOL v2 = NO;;
                            
                            for (int j = 0; j < a0.count; j++) {
                                if (a0.count > 0) {
                                    dic0 = a0[j];
                                    if ([dic0 isKindOfClass:[NSNull class]]) {
                                        dic0 = nil;
                                    }
                                    if (j == 0) {
                                        v0 = dic0 ?YES :NO;
                                    }
                                }
                                if (a1.count > 0) {
                                    dic1 = a1[j];
                                    if ([dic1 isKindOfClass:[NSNull class]]) {
                                        dic1 = nil;
                                    }
                                    if (j == 0) {
                                        v1 = dic1 ?YES :NO;
                                    }
                                }
                                if (a2.count > 0) {
                                    dic2 = a2[j];
                                    if ([dic2 isKindOfClass:[NSNull class]]) {
                                        dic2 = nil;
                                    }
                                    if (j == 0) {
                                        v2= dic2 ?YES :NO;
                                    }
                                }
                                
                                CGFloat t0 = [[dic0 objectForKey:textHeight] floatValue];
                                CGFloat t1 = [[dic1 objectForKey:textHeight] floatValue];
                                CGFloat t2 = [[dic2 objectForKey:textHeight] floatValue];
                                CGFloat maxValue = [[@[@(t0),@(t1),@(t2)] valueForKeyPath:@"@max.floatValue"] floatValue];
                                
                                if ((!v0 && dic0) || (!v1 && dic1) || (!v2 && dic2)) { //补齐合并结束时的高度
                                    CGFloat t0 = [[dic0 objectForKey:textHeight] floatValue];
                                    CGFloat t1 = [[dic1 objectForKey:textHeight] floatValue];
                                    CGFloat t2 = [[dic2 objectForKey:textHeight] floatValue];
                                    CGFloat maxValue = [[@[@(t0 + f0),@(t1 + f1),@(t2 + f2)] valueForKeyPath:@"@max.floatValue"] floatValue];
                                    if (dic0) {
                                        [dic0 setValue:@(maxValue - f0) forKey:labelHeight];
                                        f0 = maxValue;
                                    }
                                    if (dic1) {
                                        [dic1 setValue:@(maxValue - f1) forKey:labelHeight];
                                        f1 = maxValue;
                                    }
                                    if (dic2) {
                                        [dic2 setValue:@(maxValue - f2) forKey:labelHeight];
                                        f2 = maxValue;
                                    }
                                    
                                }else{
                                    if (dic0) {
                                        [dic0 setValue:@(maxValue) forKey:labelHeight];
                                        f0 += maxValue;
                                    }
                                    if (dic1) {
                                        [dic1 setValue:@(maxValue) forKey:labelHeight];
                                        f1 += maxValue;
                                    }
                                    if (dic2) {
                                        [dic2 setValue:@(maxValue) forKey:labelHeight];
                                        f2 += maxValue;
                                    }
                                }
                                
                                v0= dic0 ?YES :NO;
                                v1= dic1 ?YES :NO;
                                v2= dic2 ?YES :NO;
                                
                            }
                            
                            if (a0) {
                                [r2 addObject:[a0.reverseObjectEnumerator.allObjects mutableCopy]];
                            }
                            if (a1) {
                                [r2 addObject:[a1.reverseObjectEnumerator.allObjects mutableCopy]];
                            }
                            if (a2) {
                                [r2 addObject:[a2.reverseObjectEnumerator.allObjects mutableCopy]];
                            }
                            
                            [a0 removeAllObjects];
                            [a1 removeAllObjects];
                            [a2 removeAllObjects];
                            [r1 addObject:r2];
                            //计算行高 移除占位数据
                            for (NSMutableArray *attArray in r2) {
                                CGFloat sum = 0;
                                NSMutableArray *del = [NSMutableArray array];
                                for (NSMutableDictionary *dic in attArray) {
                                    if ([dic isKindOfClass:[NSNull class]]) {
                                        [del addObject:dic];
                                    }else{
                                        CGFloat height = [[dic objectForKey:labelHeight] floatValue];
                                        sum += height;
                                    }
                                }
                                [attArray removeObjectsInArray:del];
                                if (sum > maxH) {
                                    maxH = sum;
                                }
                            }
                            [h1 addObject:@(maxH)];
                        }
                    }
                }
            }
            [result addObject:r1.reverseObjectEnumerator.allObjects];
            [height addObject:h1.reverseObjectEnumerator.allObjects];
        }
        model.table = result;
        model.cellHeight = height;
        [self.tableView reloadData];
    }
    
}

- (NSMutableAttributedString *)attributedTextFromString:(NSString *)str{
    NSMutableAttributedString *att = [[NSMutableAttributedString alloc] initWithString:str?:@""];
    [att addAttribute:NSForegroundColorAttributeName value:[UIColor grayColor] range:NSMakeRange(0, att.length)];
    [att addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:14] range:NSMakeRange(0, att.length)];
    return att;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _model.table.count;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_model.table[section] count];
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 20)];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 20;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return [[UIView alloc] initWithFrame:CGRectZero];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{

    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat height = [_model.cellHeight[indexPath.section][indexPath.row] floatValue];
    if (height > 0) {
        if (indexPath.row == [_model.table[indexPath.section] count] -1) {
            return height + 1;
        }
        return height;
    }
    return UITableViewAutomaticDimension;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    ZhiKuTFMJContentCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(ZhiKuTFMJContentCell.class) forIndexPath:indexPath];
    _model.first = indexPath.row == 0;
    _model.last = indexPath.row == [_model.table[indexPath.section] count] -1;
    _model.cellArray = _model.table[indexPath.section][indexPath.row];
    cell.model = _model;
    
    return cell;
}



@end
