//
//  SceneDelegate.h
//  test1
//
//  Created by i on 2024/1/4.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

