//
//  ZhiKuTFMJContentCell.h
//
//  Created by i on 2023/12/20.
//

#import <UIKit/UIKit.h>
#import "ZhiKuTFMJMenuListModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ZhiKuTFMJContentCell : UITableViewCell
@property (nonatomic,strong) ZhiKuTFMJMenuListModel *model;
@end

NS_ASSUME_NONNULL_END
