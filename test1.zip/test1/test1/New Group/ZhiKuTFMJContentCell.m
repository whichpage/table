//
//  ZhiKuTFMJContentCell.m
//
//  Created by i on 2023/12/20.
//

#import "ZhiKuTFMJContentCell.h"
#import <Masonry/Masonry.h>

@interface ZhiKuTFMJContentCell ()

@property (weak, nonatomic) IBOutlet UIView *backView1;

@property (weak, nonatomic) IBOutlet UIView *backView2;
@property (weak, nonatomic) IBOutlet UIView *backView20;
@property (weak, nonatomic) IBOutlet UIView *backView21;

@property (weak, nonatomic) IBOutlet UIView *backView3;
@property (weak, nonatomic) IBOutlet UIView *backView30;
@property (weak, nonatomic) IBOutlet UIView *backView31;
@property (weak, nonatomic) IBOutlet UIView *backView32;

@end

@implementation ZhiKuTFMJContentCell

- (void)awakeFromNib {
    [super awakeFromNib];
     
}

- (void)setModel:(ZhiKuTFMJMenuListModel *)model{
    NSArray *array = model.cellArray;
    
    self.backView1.hidden = array.count != 1;
    self.backView2.hidden = array.count != 2;
    self.backView3.hidden = array.count != 3;
    
    if (array.count == 1) {
        for (UIView *view in self.backView1.subviews) {
            [view removeFromSuperview];
        }
    } else if (array.count == 2) {
        for (UIView *view in self.backView20.subviews) {
            [view removeFromSuperview];
        }
        for (UIView *view in self.backView21.subviews) {
            [view removeFromSuperview];
        }
    } else if (array.count == 3) {
        for (UIView *view in self.backView30.subviews) {
            [view removeFromSuperview];
        }
        for (UIView *view in self.backView31.subviews) {
            [view removeFromSuperview];
        }
        for (UIView *view in self.backView32.subviews) {
            [view removeFromSuperview];
        }
    }
    
    for (int i = 0; i < array.count; i++) {
        NSArray *arr = array[i];
        UIView *last;
        for (int j = 0; j < arr.count; j++) {
            NSDictionary *dic = arr[j];
            
            NSMutableAttributedString *att = [dic objectForKey:@"att"];
            CGFloat height = [[dic objectForKey:@"labelHeight"] floatValue] - 21;//减去上下间距 一条线的高度
            
            UILabel *label = [self contentLabel];
            if (model.first) {
                label.textAlignment = NSTextAlignmentCenter;
                [att addAttribute:NSFontAttributeName value:[UIFont boldSystemFontOfSize:14] range:NSMakeRange(0, att.length)];
            }
            label.attributedText = att;
            
            if (array.count == 1) {
                [self.backView1 addSubview:label];
                if (j == 0 && j != arr.count -1) {
                    [label mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.left.mas_equalTo(self.backView1).offset(10);
                        make.right.mas_equalTo(self.backView1).offset(-10);
                        make.top.mas_equalTo(self.backView1).offset(10);
                        make.height.mas_equalTo(height);
                    }];
                }
                if (j != 0 &&  j != arr.count -1) {
                    [label mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.left.mas_equalTo(self.backView1).offset(10);
                        make.right.mas_equalTo(self.backView1).offset(-10);
                        make.top.mas_equalTo(last.mas_bottom).offset(10);
                        make.height.mas_equalTo(height);
                    }];
                }
                if (j == arr.count-1) {
                    [label mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.top.mas_equalTo(j == 0 ?self.backView1 :last.mas_bottom).offset(10);
                        make.left.mas_equalTo(self.backView1).offset(10);
                        make.right.mas_equalTo(self.backView1).offset(-10);
                        make.height.mas_equalTo(height);
                    }];
                    if (model.last) {
                        UIView *line = [self contentLine];
                        [self.backView1 addSubview:line];
                        [line mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(label.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView1);
                            make.right.mas_equalTo(self.backView1);
                            make.bottom.mas_equalTo(self.backView1);
                            make.height.mas_equalTo(1);
                        }];
                    }
                }
                last = label;
                if (j != arr.count-1) {
                    UIView *line = [self contentLine];
                    [self.backView1 addSubview:line];
                    [line mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.top.mas_equalTo(label.mas_bottom).offset(10);
                        make.left.mas_equalTo(self.backView1);
                        make.right.mas_equalTo(self.backView1);
                        make.height.mas_equalTo(1);
                    }];
                    last = line;
                }
            }else if (array.count == 2){
                if (i == 0) {
                    [self.backView20 addSubview:label];
                    if (j == 0 && j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView20).offset(10);
                            make.right.mas_equalTo(self.backView20).offset(-10);
                            make.top.mas_equalTo(self.backView20).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j != 0 &&  j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView20).offset(10);
                            make.right.mas_equalTo(self.backView20).offset(-10);
                            make.top.mas_equalTo(last.mas_bottom).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j == arr.count-1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(j == 0 ?self.backView20 :last.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView20).offset(10);
                            make.right.mas_equalTo(self.backView20).offset(-10);
                            make.height.mas_equalTo(height);
                        }];
                        if (model.last) {
                            UIView *line = [self contentLine];
                            [self.backView20 addSubview:line];
                            [line mas_makeConstraints:^(MASConstraintMaker *make) {
                                make.top.mas_equalTo(label.mas_bottom).offset(10);
                                make.left.mas_equalTo(self.backView20);
                                make.right.mas_equalTo(self.backView20);
                                make.bottom.mas_equalTo(self.backView20);
                                make.height.mas_equalTo(1);
                            }];
                        }
                    }
                    last = label;
                    if (j != arr.count-1) {
                        UIView *line = [self contentLine];
                        [self.backView20 addSubview:line];
                        [line mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(label.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView20);
                            make.right.mas_equalTo(self.backView20);
                            make.height.mas_equalTo(1);
                        }];
                        last = line;
                    }
                } else if (i == 1){
                    [self.backView21 addSubview:label];
                    if (j == 0 && j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView21).offset(10);
                            make.right.mas_equalTo(self.backView21).offset(-10);
                            make.top.mas_equalTo(self.backView21).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j != 0 &&  j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView21).offset(10);
                            make.right.mas_equalTo(self.backView21).offset(-10);
                            make.top.mas_equalTo(last.mas_bottom).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j == arr.count-1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(j == 0 ?self.backView21 :last.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView21).offset(10);
                            make.right.mas_equalTo(self.backView21).offset(-10);
                            make.height.mas_equalTo(height);
                        }];
                        if (model.last) {
                            UIView *line = [self contentLine];
                            [self.backView21 addSubview:line];
                            [line mas_makeConstraints:^(MASConstraintMaker *make) {
                                make.top.mas_equalTo(label.mas_bottom).offset(10);
                                make.left.mas_equalTo(self.backView21);
                                make.right.mas_equalTo(self.backView21);
                                make.bottom.mas_equalTo(self.backView21);
                                make.height.mas_equalTo(1);
                            }];
                        }
                    }
                    last = label;
                    if (j != arr.count-1) {
                        UIView *line = [self contentLine];
                        [self.backView21 addSubview:line];
                        [line mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(label.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView21);
                            make.right.mas_equalTo(self.backView21);
                            make.height.mas_equalTo(1);
                        }];
                        last = line;
                    }
                }
            }else if (array.count == 3){
                if (i == 0) {
                    [self.backView30 addSubview:label];
                    if (j == 0 && j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView30).offset(10);
                            make.right.mas_equalTo(self.backView30).offset(-10);
                            make.top.mas_equalTo(self.backView30).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j != 0 &&  j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView30).offset(10);
                            make.right.mas_equalTo(self.backView30).offset(-10);
                            make.top.mas_equalTo(last.mas_bottom).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j == arr.count-1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(j == 0 ?self.backView30 :last.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView30).offset(10);
                            make.right.mas_equalTo(self.backView30).offset(-10);
                            make.height.mas_equalTo(height);
                        }];
                        if (model.last) {
                            UIView *line = [self contentLine];
                            [self.backView30 addSubview:line];
                            [line mas_makeConstraints:^(MASConstraintMaker *make) {
                                make.top.mas_equalTo(label.mas_bottom).offset(10);
                                make.left.mas_equalTo(self.backView30);
                                make.right.mas_equalTo(self.backView30);
                                make.bottom.mas_equalTo(self.backView30);
                                make.height.mas_equalTo(1);
                            }];
                        }
                    }
                    last = label;
                    if (j != arr.count-1) {
                        UIView *line = [self contentLine];
                        [self.backView30 addSubview:line];
                        [line mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(label.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView30);
                            make.right.mas_equalTo(self.backView30);
                            make.height.mas_equalTo(1);
                        }];
                        last = line;
                    }
                } else if (i == 1){
                    [self.backView31 addSubview:label];
                    if (j == 0 && j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView31).offset(10);
                            make.right.mas_equalTo(self.backView31).offset(-10);
                            make.top.mas_equalTo(self.backView31).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j != 0 &&  j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView31).offset(10);
                            make.right.mas_equalTo(self.backView31).offset(-10);
                            make.top.mas_equalTo(last.mas_bottom).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j == arr.count-1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(j == 0 ?self.backView31 :last.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView31).offset(10);
                            make.right.mas_equalTo(self.backView31).offset(-10);
                            make.height.mas_equalTo(height);
                        }];
                        if (model.last) {
                            UIView *line = [self contentLine];
                            [self.backView31 addSubview:line];
                            [line mas_makeConstraints:^(MASConstraintMaker *make) {
                                make.top.mas_equalTo(label.mas_bottom).offset(10);
                                make.left.mas_equalTo(self.backView31);
                                make.right.mas_equalTo(self.backView31);
                                make.bottom.mas_equalTo(self.backView31);
                                make.height.mas_equalTo(1);
                            }];
                        }
                    }
                    last = label;
                    if (j != arr.count-1) {
                        UIView *line = [self contentLine];
                        [self.backView31 addSubview:line];
                        [line mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(label.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView31);
                            make.right.mas_equalTo(self.backView31);
                            make.height.mas_equalTo(1);
                        }];
                        last = line;
                    }
                } else if (i == 2){
                    [self.backView32 addSubview:label];
                    if (j == 0 && j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView32).offset(10);
                            make.right.mas_equalTo(self.backView32).offset(-10);
                            make.top.mas_equalTo(self.backView32).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j != 0 &&  j != arr.count -1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.left.mas_equalTo(self.backView32).offset(10);
                            make.right.mas_equalTo(self.backView32).offset(-10);
                            make.top.mas_equalTo(last.mas_bottom).offset(10);
                            make.height.mas_equalTo(height);
                        }];
                    }
                    if (j == arr.count-1) {
                        [label mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(j == 0 ?self.backView32 :last.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView32).offset(10);
                            make.right.mas_equalTo(self.backView32).offset(-10);
                            make.height.mas_equalTo(height);
                        }];
                        if (model.last) {
                            UIView *line = [self contentLine];
                            [self.backView32 addSubview:line];
                            [line mas_makeConstraints:^(MASConstraintMaker *make) {
                                make.top.mas_equalTo(label.mas_bottom).offset(10);
                                make.left.mas_equalTo(self.backView32);
                                make.right.mas_equalTo(self.backView32);
                                make.bottom.mas_equalTo(self.backView32);
                                make.height.mas_equalTo(1);
                            }];
                        }
                    }
                    last = label;
                    if (j != arr.count-1) {
                        UIView *line = [self contentLine];
                        [self.backView32 addSubview:line];
                        [line mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.top.mas_equalTo(label.mas_bottom).offset(10);
                            make.left.mas_equalTo(self.backView32);
                            make.right.mas_equalTo(self.backView32);
                            make.height.mas_equalTo(1);
                        }];
                        last = line;
                    }
                }
            }
        }
    }
}

- (UIView *)contentLine{
    UIView *line = [[UIView alloc] init];
    line.backgroundColor = [UIColor colorWithRed:91 /255.0 green:184 /255.0 blue:255 /255.0 alpha:1];
    return line;
}

- (UILabel *)contentLabel{
    UILabel *label = [[UILabel alloc] init];
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor grayColor];
    label.numberOfLines = 0;
    return label;
}


@end
