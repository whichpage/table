//
//  ZhiKuTFMJMenuListModel.m
//
//  Created by i on 2023/12/19.
//

#import "ZhiKuTFMJMenuListModel.h"

@implementation ZhiKuTFMJMenuListModel

@end
