//
//  ZhiKuTFMJMenuListModel.h
//
//  Created by i on 2023/12/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZhiKuTFMJMenuListModel : NSObject

@property (nonatomic, strong) NSArray *table;
@property (nonatomic, strong) NSArray *cellHeight;
@property (nonatomic, strong) NSArray *cellArray;
@property (nonatomic, assign) BOOL first;
@property (nonatomic, assign) BOOL last;
@property (nonatomic, strong) NSIndexPath *indexPath;

@end

NS_ASSUME_NONNULL_END
